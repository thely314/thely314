<div align="center">
  <img
    width="320px"
    alt="visitors"
    src="https://count.getloli.com/get/@thely314?theme=booru-jaypee"
  />
</div>

##### 👋 Nice to meet you

I'm **lone**(thely314 for former name), a student from Sun Yat-sen University majoring in Software Engineering.

<div align="center">
  <img height="320px" src="https://github-readme-stats.vercel.app/api/top-langs/?username=thely314&?hide=javascript,html,asl&langs_count=6"/>
  <img height="320px" src="https://github-readme-stats.vercel.app/api?username=thely314&show_icons=true&line_height=40"/>
</div>
